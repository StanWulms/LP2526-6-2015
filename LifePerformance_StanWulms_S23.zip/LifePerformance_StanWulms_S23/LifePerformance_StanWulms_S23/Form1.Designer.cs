﻿namespace LifePerformance_StanWulms_S23
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBootID = new System.Windows.Forms.Label();
            this.lblHoopY = new System.Windows.Forms.Label();
            this.lblHopeX = new System.Windows.Forms.Label();
            this.lblHoopBeschrijving = new System.Windows.Forms.Label();
            this.tbBootID = new System.Windows.Forms.TextBox();
            this.tbHopeY = new System.Windows.Forms.TextBox();
            this.tbHopeX = new System.Windows.Forms.TextBox();
            this.tbHopeBeschrijving = new System.Windows.Forms.TextBox();
            this.lbHOPEmissies = new System.Windows.Forms.ListBox();
            this.btnHopeToevoegen = new System.Windows.Forms.Button();
            this.btnHopeWijzigen = new System.Windows.Forms.Button();
            this.btnHopeVerwijderen = new System.Windows.Forms.Button();
            this.lblVertrektijd = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbMetingTijdstip = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnMetingVerwijderen = new System.Windows.Forms.Button();
            this.btnMetingWijzigen = new System.Windows.Forms.Button();
            this.btnMetingToevoegen = new System.Windows.Forms.Button();
            this.lbMetingen = new System.Windows.Forms.ListBox();
            this.tbMetingBeschrijving = new System.Windows.Forms.TextBox();
            this.tbMetingX = new System.Windows.Forms.TextBox();
            this.tbMetingY = new System.Windows.Forms.TextBox();
            this.tbHopeID = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dtpHopeVertrek = new System.Windows.Forms.DateTimePicker();
            this.dtpHopeAankomst = new System.Windows.Forms.DateTimePicker();
            this.dtpMetingTijdstip = new System.Windows.Forms.DateTimePicker();
            this.dtpSinVertrektijd = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.btnSinVerwijderen = new System.Windows.Forms.Button();
            this.btnSinWijzigen = new System.Windows.Forms.Button();
            this.btnSinToevoegen = new System.Windows.Forms.Button();
            this.lbSINmissies = new System.Windows.Forms.ListBox();
            this.tbSinBeschrijving = new System.Windows.Forms.TextBox();
            this.tbSinX = new System.Windows.Forms.TextBox();
            this.tbSinY = new System.Windows.Forms.TextBox();
            this.tbSinBootID = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblIncidenten = new System.Windows.Forms.Label();
            this.rtbIncidentBeschrijving = new System.Windows.Forms.RichTextBox();
            this.lbIncidenten = new System.Windows.Forms.ListBox();
            this.btnIncidentVerwijderen = new System.Windows.Forms.Button();
            this.btnIncidentWijzigen = new System.Windows.Forms.Button();
            this.btnIncidentToevoegen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblBootID
            // 
            this.lblBootID.AutoSize = true;
            this.lblBootID.Location = new System.Drawing.Point(40, 70);
            this.lblBootID.Name = "lblBootID";
            this.lblBootID.Size = new System.Drawing.Size(58, 17);
            this.lblBootID.TabIndex = 0;
            this.lblBootID.Text = "Boot ID:";
            // 
            // lblHoopY
            // 
            this.lblHoopY.AutoSize = true;
            this.lblHoopY.Location = new System.Drawing.Point(40, 171);
            this.lblHoopY.Name = "lblHoopY";
            this.lblHoopY.Size = new System.Drawing.Size(93, 17);
            this.lblHoopY.TabIndex = 3;
            this.lblHoopY.Text = "Y-coördinaat:";
            // 
            // lblHopeX
            // 
            this.lblHopeX.AutoSize = true;
            this.lblHopeX.Location = new System.Drawing.Point(40, 143);
            this.lblHopeX.Name = "lblHopeX";
            this.lblHopeX.Size = new System.Drawing.Size(93, 17);
            this.lblHopeX.TabIndex = 4;
            this.lblHopeX.Text = "X-coördinaat:";
            // 
            // lblHoopBeschrijving
            // 
            this.lblHoopBeschrijving.AutoSize = true;
            this.lblHoopBeschrijving.Location = new System.Drawing.Point(40, 112);
            this.lblHoopBeschrijving.Name = "lblHoopBeschrijving";
            this.lblHoopBeschrijving.Size = new System.Drawing.Size(88, 17);
            this.lblHoopBeschrijving.TabIndex = 5;
            this.lblHoopBeschrijving.Text = "Beschrijving:";
            // 
            // tbBootID
            // 
            this.tbBootID.Location = new System.Drawing.Point(164, 70);
            this.tbBootID.Name = "tbBootID";
            this.tbBootID.Size = new System.Drawing.Size(100, 22);
            this.tbBootID.TabIndex = 6;
            // 
            // tbHopeY
            // 
            this.tbHopeY.Location = new System.Drawing.Point(164, 171);
            this.tbHopeY.Name = "tbHopeY";
            this.tbHopeY.Size = new System.Drawing.Size(100, 22);
            this.tbHopeY.TabIndex = 8;
            // 
            // tbHopeX
            // 
            this.tbHopeX.Location = new System.Drawing.Point(164, 143);
            this.tbHopeX.Name = "tbHopeX";
            this.tbHopeX.Size = new System.Drawing.Size(100, 22);
            this.tbHopeX.TabIndex = 9;
            // 
            // tbHopeBeschrijving
            // 
            this.tbHopeBeschrijving.Location = new System.Drawing.Point(164, 112);
            this.tbHopeBeschrijving.Name = "tbHopeBeschrijving";
            this.tbHopeBeschrijving.Size = new System.Drawing.Size(100, 22);
            this.tbHopeBeschrijving.TabIndex = 10;
            // 
            // lbHOPEmissies
            // 
            this.lbHOPEmissies.FormattingEnabled = true;
            this.lbHOPEmissies.ItemHeight = 16;
            this.lbHOPEmissies.Location = new System.Drawing.Point(353, 70);
            this.lbHOPEmissies.Name = "lbHOPEmissies";
            this.lbHOPEmissies.Size = new System.Drawing.Size(244, 212);
            this.lbHOPEmissies.TabIndex = 11;
            // 
            // btnHopeToevoegen
            // 
            this.btnHopeToevoegen.Location = new System.Drawing.Point(43, 300);
            this.btnHopeToevoegen.Name = "btnHopeToevoegen";
            this.btnHopeToevoegen.Size = new System.Drawing.Size(221, 23);
            this.btnHopeToevoegen.TabIndex = 12;
            this.btnHopeToevoegen.Text = "HOPE Toevoegen";
            this.btnHopeToevoegen.UseVisualStyleBackColor = true;
            this.btnHopeToevoegen.Click += new System.EventHandler(this.btnHopeToevoegen_Click);
            // 
            // btnHopeWijzigen
            // 
            this.btnHopeWijzigen.Location = new System.Drawing.Point(353, 299);
            this.btnHopeWijzigen.Name = "btnHopeWijzigen";
            this.btnHopeWijzigen.Size = new System.Drawing.Size(112, 23);
            this.btnHopeWijzigen.TabIndex = 13;
            this.btnHopeWijzigen.Text = "Wijzigen";
            this.btnHopeWijzigen.UseVisualStyleBackColor = true;
            // 
            // btnHopeVerwijderen
            // 
            this.btnHopeVerwijderen.Location = new System.Drawing.Point(485, 300);
            this.btnHopeVerwijderen.Name = "btnHopeVerwijderen";
            this.btnHopeVerwijderen.Size = new System.Drawing.Size(112, 23);
            this.btnHopeVerwijderen.TabIndex = 14;
            this.btnHopeVerwijderen.Text = "Verwijderen";
            this.btnHopeVerwijderen.UseVisualStyleBackColor = true;
            // 
            // lblVertrektijd
            // 
            this.lblVertrektijd.AutoSize = true;
            this.lblVertrektijd.Location = new System.Drawing.Point(43, 228);
            this.lblVertrektijd.Name = "lblVertrektijd";
            this.lblVertrektijd.Size = new System.Drawing.Size(76, 17);
            this.lblVertrektijd.TabIndex = 16;
            this.lblVertrektijd.Text = "Vertrektijd:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 261);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 17);
            this.label7.TabIndex = 17;
            this.label7.Text = "Aankomsttijd:";
            // 
            // tbMetingTijdstip
            // 
            this.tbMetingTijdstip.Location = new System.Drawing.Point(787, 228);
            this.tbMetingTijdstip.Name = "tbMetingTijdstip";
            this.tbMetingTijdstip.Size = new System.Drawing.Size(100, 22);
            this.tbMetingTijdstip.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(666, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 17);
            this.label3.TabIndex = 32;
            this.label3.Text = "TijdStip: ";
            // 
            // btnMetingVerwijderen
            // 
            this.btnMetingVerwijderen.Location = new System.Drawing.Point(1108, 300);
            this.btnMetingVerwijderen.Name = "btnMetingVerwijderen";
            this.btnMetingVerwijderen.Size = new System.Drawing.Size(112, 23);
            this.btnMetingVerwijderen.TabIndex = 31;
            this.btnMetingVerwijderen.Text = "Verwijderen";
            this.btnMetingVerwijderen.UseVisualStyleBackColor = true;
            // 
            // btnMetingWijzigen
            // 
            this.btnMetingWijzigen.Location = new System.Drawing.Point(976, 299);
            this.btnMetingWijzigen.Name = "btnMetingWijzigen";
            this.btnMetingWijzigen.Size = new System.Drawing.Size(112, 23);
            this.btnMetingWijzigen.TabIndex = 30;
            this.btnMetingWijzigen.Text = "Wijzigen";
            this.btnMetingWijzigen.UseVisualStyleBackColor = true;
            // 
            // btnMetingToevoegen
            // 
            this.btnMetingToevoegen.Location = new System.Drawing.Point(666, 300);
            this.btnMetingToevoegen.Name = "btnMetingToevoegen";
            this.btnMetingToevoegen.Size = new System.Drawing.Size(221, 23);
            this.btnMetingToevoegen.TabIndex = 29;
            this.btnMetingToevoegen.Text = "Meting Toevoegen";
            this.btnMetingToevoegen.UseVisualStyleBackColor = true;
            this.btnMetingToevoegen.Click += new System.EventHandler(this.btnMetingToevoegen_Click);
            // 
            // lbMetingen
            // 
            this.lbMetingen.FormattingEnabled = true;
            this.lbMetingen.ItemHeight = 16;
            this.lbMetingen.Location = new System.Drawing.Point(976, 70);
            this.lbMetingen.Name = "lbMetingen";
            this.lbMetingen.Size = new System.Drawing.Size(244, 212);
            this.lbMetingen.TabIndex = 28;
            // 
            // tbMetingBeschrijving
            // 
            this.tbMetingBeschrijving.Location = new System.Drawing.Point(787, 112);
            this.tbMetingBeschrijving.Name = "tbMetingBeschrijving";
            this.tbMetingBeschrijving.Size = new System.Drawing.Size(100, 22);
            this.tbMetingBeschrijving.TabIndex = 27;
            // 
            // tbMetingX
            // 
            this.tbMetingX.Location = new System.Drawing.Point(787, 143);
            this.tbMetingX.Name = "tbMetingX";
            this.tbMetingX.Size = new System.Drawing.Size(100, 22);
            this.tbMetingX.TabIndex = 26;
            // 
            // tbMetingY
            // 
            this.tbMetingY.Location = new System.Drawing.Point(787, 171);
            this.tbMetingY.Name = "tbMetingY";
            this.tbMetingY.Size = new System.Drawing.Size(100, 22);
            this.tbMetingY.TabIndex = 25;
            // 
            // tbHopeID
            // 
            this.tbHopeID.Location = new System.Drawing.Point(787, 70);
            this.tbHopeID.Name = "tbHopeID";
            this.tbHopeID.Size = new System.Drawing.Size(100, 22);
            this.tbHopeID.TabIndex = 24;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(663, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 17);
            this.label8.TabIndex = 23;
            this.label8.Text = "Beschrijving:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(663, 143);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 17);
            this.label9.TabIndex = 22;
            this.label9.Text = "X-coördinaat:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(663, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "Y-coördinaat:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(663, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 17);
            this.label11.TabIndex = 20;
            this.label11.Text = "Hope  ID:";
            // 
            // dtpHopeVertrek
            // 
            this.dtpHopeVertrek.CustomFormat = "DD-MM-RR";
            this.dtpHopeVertrek.Location = new System.Drawing.Point(164, 231);
            this.dtpHopeVertrek.Name = "dtpHopeVertrek";
            this.dtpHopeVertrek.Size = new System.Drawing.Size(163, 22);
            this.dtpHopeVertrek.TabIndex = 35;
            // 
            // dtpHopeAankomst
            // 
            this.dtpHopeAankomst.CustomFormat = "DD-MM-RR";
            this.dtpHopeAankomst.Location = new System.Drawing.Point(164, 259);
            this.dtpHopeAankomst.Name = "dtpHopeAankomst";
            this.dtpHopeAankomst.Size = new System.Drawing.Size(163, 22);
            this.dtpHopeAankomst.TabIndex = 36;
            // 
            // dtpMetingTijdstip
            // 
            this.dtpMetingTijdstip.CustomFormat = "DD-MM-RR";
            this.dtpMetingTijdstip.Location = new System.Drawing.Point(787, 227);
            this.dtpMetingTijdstip.Name = "dtpMetingTijdstip";
            this.dtpMetingTijdstip.Size = new System.Drawing.Size(148, 22);
            this.dtpMetingTijdstip.TabIndex = 37;
            // 
            // dtpSinVertrektijd
            // 
            this.dtpSinVertrektijd.Location = new System.Drawing.Point(164, 550);
            this.dtpSinVertrektijd.Name = "dtpSinVertrektijd";
            this.dtpSinVertrektijd.Size = new System.Drawing.Size(163, 22);
            this.dtpSinVertrektijd.TabIndex = 52;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(43, 547);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 17);
            this.label12.TabIndex = 50;
            this.label12.Text = "Vertrektijd:";
            // 
            // btnSinVerwijderen
            // 
            this.btnSinVerwijderen.Location = new System.Drawing.Point(485, 619);
            this.btnSinVerwijderen.Name = "btnSinVerwijderen";
            this.btnSinVerwijderen.Size = new System.Drawing.Size(112, 23);
            this.btnSinVerwijderen.TabIndex = 49;
            this.btnSinVerwijderen.Text = "Verwijderen";
            this.btnSinVerwijderen.UseVisualStyleBackColor = true;
            // 
            // btnSinWijzigen
            // 
            this.btnSinWijzigen.Location = new System.Drawing.Point(353, 618);
            this.btnSinWijzigen.Name = "btnSinWijzigen";
            this.btnSinWijzigen.Size = new System.Drawing.Size(112, 23);
            this.btnSinWijzigen.TabIndex = 48;
            this.btnSinWijzigen.Text = "Wijzigen";
            this.btnSinWijzigen.UseVisualStyleBackColor = true;
            // 
            // btnSinToevoegen
            // 
            this.btnSinToevoegen.Location = new System.Drawing.Point(43, 619);
            this.btnSinToevoegen.Name = "btnSinToevoegen";
            this.btnSinToevoegen.Size = new System.Drawing.Size(221, 23);
            this.btnSinToevoegen.TabIndex = 47;
            this.btnSinToevoegen.Text = "SIN Toevoegen";
            this.btnSinToevoegen.UseVisualStyleBackColor = true;
            // 
            // lbSINmissies
            // 
            this.lbSINmissies.FormattingEnabled = true;
            this.lbSINmissies.ItemHeight = 16;
            this.lbSINmissies.Location = new System.Drawing.Point(353, 389);
            this.lbSINmissies.Name = "lbSINmissies";
            this.lbSINmissies.Size = new System.Drawing.Size(244, 212);
            this.lbSINmissies.TabIndex = 46;
            // 
            // tbSinBeschrijving
            // 
            this.tbSinBeschrijving.Location = new System.Drawing.Point(164, 431);
            this.tbSinBeschrijving.Name = "tbSinBeschrijving";
            this.tbSinBeschrijving.Size = new System.Drawing.Size(100, 22);
            this.tbSinBeschrijving.TabIndex = 45;
            // 
            // tbSinX
            // 
            this.tbSinX.Location = new System.Drawing.Point(164, 462);
            this.tbSinX.Name = "tbSinX";
            this.tbSinX.Size = new System.Drawing.Size(100, 22);
            this.tbSinX.TabIndex = 44;
            // 
            // tbSinY
            // 
            this.tbSinY.Location = new System.Drawing.Point(164, 490);
            this.tbSinY.Name = "tbSinY";
            this.tbSinY.Size = new System.Drawing.Size(100, 22);
            this.tbSinY.TabIndex = 43;
            // 
            // tbSinBootID
            // 
            this.tbSinBootID.Location = new System.Drawing.Point(164, 389);
            this.tbSinBootID.Name = "tbSinBootID";
            this.tbSinBootID.Size = new System.Drawing.Size(100, 22);
            this.tbSinBootID.TabIndex = 42;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(40, 431);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(88, 17);
            this.label13.TabIndex = 41;
            this.label13.Text = "Beschrijving:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(40, 462);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 17);
            this.label14.TabIndex = 40;
            this.label14.Text = "X-coördinaat:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(40, 490);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 17);
            this.label15.TabIndex = 39;
            this.label15.Text = "Y-coördinaat:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(40, 389);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(58, 17);
            this.label16.TabIndex = 38;
            this.label16.Text = "Boot ID:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(273, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(93, 17);
            this.label17.TabIndex = 54;
            this.label17.Text = "Hope-missies";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(881, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 17);
            this.label18.TabIndex = 55;
            this.label18.Text = "Metingen";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(276, 354);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 17);
            this.label19.TabIndex = 56;
            this.label19.Text = "Sin-missies";
            // 
            // lblIncidenten
            // 
            this.lblIncidenten.AutoSize = true;
            this.lblIncidenten.Location = new System.Drawing.Point(884, 354);
            this.lblIncidenten.Name = "lblIncidenten";
            this.lblIncidenten.Size = new System.Drawing.Size(73, 17);
            this.lblIncidenten.TabIndex = 57;
            this.lblIncidenten.Text = "Incidenten";
            // 
            // rtbIncidentBeschrijving
            // 
            this.rtbIncidentBeschrijving.Location = new System.Drawing.Point(689, 389);
            this.rtbIncidentBeschrijving.Name = "rtbIncidentBeschrijving";
            this.rtbIncidentBeschrijving.Size = new System.Drawing.Size(246, 201);
            this.rtbIncidentBeschrijving.TabIndex = 58;
            this.rtbIncidentBeschrijving.Text = "";
            // 
            // lbIncidenten
            // 
            this.lbIncidenten.FormattingEnabled = true;
            this.lbIncidenten.ItemHeight = 16;
            this.lbIncidenten.Location = new System.Drawing.Point(976, 378);
            this.lbIncidenten.Name = "lbIncidenten";
            this.lbIncidenten.Size = new System.Drawing.Size(244, 212);
            this.lbIncidenten.TabIndex = 59;
            // 
            // btnIncidentVerwijderen
            // 
            this.btnIncidentVerwijderen.Location = new System.Drawing.Point(1108, 619);
            this.btnIncidentVerwijderen.Name = "btnIncidentVerwijderen";
            this.btnIncidentVerwijderen.Size = new System.Drawing.Size(112, 23);
            this.btnIncidentVerwijderen.TabIndex = 62;
            this.btnIncidentVerwijderen.Text = "Verwijderen";
            this.btnIncidentVerwijderen.UseVisualStyleBackColor = true;
            // 
            // btnIncidentWijzigen
            // 
            this.btnIncidentWijzigen.Location = new System.Drawing.Point(976, 618);
            this.btnIncidentWijzigen.Name = "btnIncidentWijzigen";
            this.btnIncidentWijzigen.Size = new System.Drawing.Size(112, 23);
            this.btnIncidentWijzigen.TabIndex = 61;
            this.btnIncidentWijzigen.Text = "Wijzigen";
            this.btnIncidentWijzigen.UseVisualStyleBackColor = true;
            // 
            // btnIncidentToevoegen
            // 
            this.btnIncidentToevoegen.Location = new System.Drawing.Point(666, 619);
            this.btnIncidentToevoegen.Name = "btnIncidentToevoegen";
            this.btnIncidentToevoegen.Size = new System.Drawing.Size(221, 23);
            this.btnIncidentToevoegen.TabIndex = 60;
            this.btnIncidentToevoegen.Text = "Incident Toevoegen";
            this.btnIncidentToevoegen.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1232, 709);
            this.Controls.Add(this.btnIncidentVerwijderen);
            this.Controls.Add(this.btnIncidentWijzigen);
            this.Controls.Add(this.btnIncidentToevoegen);
            this.Controls.Add(this.lbIncidenten);
            this.Controls.Add(this.rtbIncidentBeschrijving);
            this.Controls.Add(this.lblIncidenten);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dtpSinVertrektijd);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnSinVerwijderen);
            this.Controls.Add(this.btnSinWijzigen);
            this.Controls.Add(this.btnSinToevoegen);
            this.Controls.Add(this.lbSINmissies);
            this.Controls.Add(this.tbSinBeschrijving);
            this.Controls.Add(this.tbSinX);
            this.Controls.Add(this.tbSinY);
            this.Controls.Add(this.tbSinBootID);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.dtpMetingTijdstip);
            this.Controls.Add(this.dtpHopeAankomst);
            this.Controls.Add(this.dtpHopeVertrek);
            this.Controls.Add(this.tbMetingTijdstip);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnMetingVerwijderen);
            this.Controls.Add(this.btnMetingWijzigen);
            this.Controls.Add(this.btnMetingToevoegen);
            this.Controls.Add(this.lbMetingen);
            this.Controls.Add(this.tbMetingBeschrijving);
            this.Controls.Add(this.tbMetingX);
            this.Controls.Add(this.tbMetingY);
            this.Controls.Add(this.tbHopeID);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblVertrektijd);
            this.Controls.Add(this.btnHopeVerwijderen);
            this.Controls.Add(this.btnHopeWijzigen);
            this.Controls.Add(this.btnHopeToevoegen);
            this.Controls.Add(this.lbHOPEmissies);
            this.Controls.Add(this.tbHopeBeschrijving);
            this.Controls.Add(this.tbHopeX);
            this.Controls.Add(this.tbHopeY);
            this.Controls.Add(this.tbBootID);
            this.Controls.Add(this.lblHoopBeschrijving);
            this.Controls.Add(this.lblHopeX);
            this.Controls.Add(this.lblHoopY);
            this.Controls.Add(this.lblBootID);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBootID;
        private System.Windows.Forms.Label lblHoopY;
        private System.Windows.Forms.Label lblHopeX;
        private System.Windows.Forms.Label lblHoopBeschrijving;
        private System.Windows.Forms.TextBox tbBootID;
        private System.Windows.Forms.TextBox tbHopeY;
        private System.Windows.Forms.TextBox tbHopeX;
        private System.Windows.Forms.TextBox tbHopeBeschrijving;
        private System.Windows.Forms.ListBox lbHOPEmissies;
        private System.Windows.Forms.Button btnHopeToevoegen;
        private System.Windows.Forms.Button btnHopeWijzigen;
        private System.Windows.Forms.Button btnHopeVerwijderen;
        private System.Windows.Forms.Label lblVertrektijd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbMetingTijdstip;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnMetingVerwijderen;
        private System.Windows.Forms.Button btnMetingWijzigen;
        private System.Windows.Forms.Button btnMetingToevoegen;
        private System.Windows.Forms.ListBox lbMetingen;
        private System.Windows.Forms.TextBox tbMetingBeschrijving;
        private System.Windows.Forms.TextBox tbMetingX;
        private System.Windows.Forms.TextBox tbMetingY;
        private System.Windows.Forms.TextBox tbHopeID;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtpHopeVertrek;
        private System.Windows.Forms.DateTimePicker dtpHopeAankomst;
        private System.Windows.Forms.DateTimePicker dtpMetingTijdstip;
        private System.Windows.Forms.DateTimePicker dtpSinVertrektijd;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnSinVerwijderen;
        private System.Windows.Forms.Button btnSinWijzigen;
        private System.Windows.Forms.Button btnSinToevoegen;
        private System.Windows.Forms.ListBox lbSINmissies;
        private System.Windows.Forms.TextBox tbSinBeschrijving;
        private System.Windows.Forms.TextBox tbSinX;
        private System.Windows.Forms.TextBox tbSinY;
        private System.Windows.Forms.TextBox tbSinBootID;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblIncidenten;
        private System.Windows.Forms.RichTextBox rtbIncidentBeschrijving;
        private System.Windows.Forms.ListBox lbIncidenten;
        private System.Windows.Forms.Button btnIncidentVerwijderen;
        private System.Windows.Forms.Button btnIncidentWijzigen;
        private System.Windows.Forms.Button btnIncidentToevoegen;
    }
}

